import glob
from tkinter import filedialog
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Load your data
#
data_root = filedialog.askdirectory()

files = glob.glob(rf"{data_root}\*.csv")

files = [file for file in files if "val" in file]

for file in files:
    data = pd.read_csv(file)
    # Replace parentheses in column names with square brackets
    data.columns = [col.replace("(", "[").replace(")", "]") for col in data.columns]

    # Extract relevant columns

    time = data["Time [s]"]

    # Create figure with secondary y-axis
    fig = make_subplots(rows=1, cols=1, specs=[[{"secondary_y": True}]])

    # Add Voltage trace to the first y-axis
    first = True
    for ycol in [col for col in data.columns if "Cell voltage" in col]:
        fig.add_trace(
            go.Scatter(
                x=time,
                y=data[ycol],
                name="Simulated voltage [V]",
                line=dict(color="blue"),
                showlegend=True if first else False,
            ),
            row=1,
            col=1,
        )
        fig.add_trace(
            go.Scatter(
                x=time,
                y=data[ycol] - data[ycol.replace("Cell voltage", "Voltage error")],
                name="Test voltage [V]",
                line=dict(color="grey"),
                showlegend=True if first else False,
            ),
            row=1,
            col=1,
        )
        ycol = ycol.replace("Cell voltage", "Cell OCV")
        fig.add_trace(
            go.Scatter(
                x=time,
                y=data[ycol],
                name="Simulated OCV [V]",
                line=dict(color="green"),
                showlegend=True if first else False,
            ),
            row=1,
            col=1,
        )
        first = False

    # Add test trace to the first y-axis
    # first = True
    # for ycol in [col for col in data.columns if "Capacity error" in col]:
    #     # Get index of 0 current
    #     y_current = ycol.replace("Capacity error", "Cell current")
    #     y_current = y_current.replace("[Ah]", "[A]")
    #     idx = data[data[y_current] == 0].index
    #     data[ycol].iloc[idx] = 0
    #     Q_cum = data[ycol].cumsum()
    #     fig.add_trace(
    #         go.Scatter(
    #             x=time,
    #             y=data[ycol],
    #             name="Capacity error [Ah]",
    #             line=dict(color="magenta"),
    #             showlegend=True if first else False,
    #         ),
    #         row=2,
    #         col=1,
    #     )
    #     fig.add_trace(
    #         go.Scatter(
    #             x=time,
    #             y=Q_cum,
    #             name="Cumulative capacity error [Ah]",
    #             line=dict(color="cyan"),
    #             showlegend=False,
    #         ),
    #         row=2,
    #         col=1,
    #         secondary_y=True,
    #     )
    #     first = False

    # Add Error trace to the second y-axis
    first = True
    anno_text = ""
    y_idx = 0
    for ycol in [col for col in data.columns if "voltage error" in col.lower()]:
        fig.add_trace(
            go.Scatter(
                x=time,
                y=data[ycol],
                name="Error [V]",
                line=dict(color="red", dash="dash"),
                showlegend=True if first else False,
            ),
            row=1,
            col=1,
            secondary_y=True,
        )
        # Calculate RMSE, max, and mean error
        rmse = np.sqrt(np.mean(np.square(data[ycol])))
        max_error = np.max(np.abs(data[ycol]))
        mean_error = np.mean(data[ycol])
        stddev_error = np.std(data[ycol])
        # Add RMSE, Max Error, and Mean Error annotations
        anno_text = (
            anno_text
            + f"{y_idx}: RMSE: {rmse:.6f}V, Max Error: {max_error:.6f}V, Mean Error: {mean_error:.6f}V, Std.Dev Error: {stddev_error:.6f}V<br>"
        )
        print(anno_text)
        y_idx += 1
        first = False

    # Add layout details including secondary y-axis
    plot_title = (
        file.split("\\")[-1].replace("out_time_probes_", "").replace("_val.csv", "")
    )
    fig.update_layout(
        title={"text": plot_title, "x": 0.5, "xanchor": "center"},
        xaxis_title="Time [s]",
        yaxis_title="Voltage [V]",
        yaxis2=dict(title="Error [V]", overlaying="y", side="right"),
        # legend=dict(x=0.1, y=0.9),
    )
    fig.update_xaxes(
        mirror=True,
        ticks="outside",
        showline=True,
        linecolor="black",
        showgrid=False,
    )
    fig.update_yaxes(
        ticks="outside",
        showline=True,
        linecolor="black",
        showgrid=False,
    )

    annotations = [
        dict(
            x=0.5,
            y=1.0,
            xref="paper",
            yref="paper",
            showarrow=False,
            text=anno_text,
            font=dict(size=12),
        )
    ]

    fig.update_layout(plot_bgcolor="white", annotations=annotations)
    out_file = f"{file.replace('csv', 'html')}"

    fig.write_html(out_file)

    # Show the figure
    fig.show()
