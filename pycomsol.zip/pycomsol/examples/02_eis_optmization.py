import pycomsol

param_filepath = "path_to_parameter_file"
model = pycomsol.DFN(param_filepath)

# Optimization features can be controlled
# using the optimization features class
opt = pycomsol.OptimizationFeatures()

opt.add_parameter("f_Rc", -2, 1, -9, 2)
opt.add_parameter("f_nm_pos", -8, 1, -10, 2)
opt.add_parameter("f_i0_Li", 0, 1, -3, 3)
opt.add_parameter("f_cdl_Li", -6, 1, -8, 0)
opt.add_parameter("f_k_pos", 2, 1, -3, 3)
opt.add_parameter("f_cdl_pos", 0, 1, -2, 2)
opt.add_parameter("f_DLi_pos", 0, 1, -2, 2)

eis_opt = pycomsol.Study(
    name="eis_optimization",
    tag="eis_opt",
    input_tables={"eis_data": "path_to_input_eis_csv"},
    output_tables=["eis_probe"],
    features=opt.features,
)

sim = pycomsol.Simulation(model, studies=eis_opt)
sol = sim.solve()
