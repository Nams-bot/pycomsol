import pycomsol
import pandas as pd
from loguru import logger
from scipy.interpolate import PchipInterpolator
from datetime import date
import numpy as np
import os

# Step 0: Set the model root path
root_path = rf"C:\Users\{os.getlogin()}\northvolt.com\Simulation and Modeling - Documents\02_Projects\13_Scania_PPE_CV_Gen2\04_Cell_Electrochemical\B0"
# Step 1: Locate the COMSOL model file
today = date.today().strftime("%Y%m%d")
model_path = rf"{root_path}\01_Input\Models\LIB_FullCell_HPPC_MultiObj_CO241205.mph"
param_filepath = rf"{root_path}\01_Input\PPE-CV-GEN2_B0_DFN-Parameters_v2.xlsx"

# Step 4: Read test data from pickle file
logger.info("Reading HPPC test data...")
ocv_path = rf"{root_path}\01_Input\OCV\Cell\OCV_balanced_PPE-CV-GEN2_GITT.csv"
hppc_path = rf"{root_path}\01_Input\Test_Data\Data_PPE_CV_GEN2_B0_HPPC_241029.pickle"
hppc_data = pd.read_pickle(hppc_path)

output_path = rf"{root_path}\02_Process\01_Parametrisation\HPPC\output_{today}_2"

if not os.path.exists(output_path):
    os.makedirs(output_path)
tmp_path = rf"{output_path}\tmp"
if not os.path.exists(tmp_path):
    os.makedirs(tmp_path)


# Load the model
model = pycomsol.DFN(param_filepath, model_path=model_path)

# Optimization features can be controlled
# using the optimization features class
opt = pycomsol.OptimizationFeatures(name="lsqo")

# opt.add_parameter()
optim_parameters = {
    "f_d_sei_neg": [1, 2, -2, 2],
    "f_k_neg": [0, 2, -2, 2],
    "f_k_pos": [0, 2, -2, 2],
    "f_cdl_neg": [0, 1, -1, 1],
    "f_cdl_pos": [0, 1, -1, 1],
    # "nm_neg": [10, 10, 5, 25],
    # "nm_pos": [18, 10, 5, 25],
    # "f_DLi_neg": [0, 2, -2, 2],
    # "f_DLi_pos": [0, 2, -2, 2],
    # "f_r_neg": [0, 0.01, -0.02, 0.02],
    # "f_r_pos": [0, 0.01, -0.02, 0.02],
}
for key, value in optim_parameters.items():
    opt.add_parameter(key, *value)

# Using global optimization physics class
# to define the objective functions
global_opt = pycomsol.GlobalOptimization(name="opt")

# Step 6: Run the optimization
t_opt = 0.2  # seconds
# t_opt = 1  # seconds
# t_opt = 60  # seconds

# SoC = [90]
SoC = [50, 40, 30, 20, 10]
T_expts = [25]
out_params = {}
# Get global variables
ocv_table = pd.read_csv(ocv_path)
ocv_interp = PchipInterpolator(ocv_table["SOC [1]"].values, ocv_table["OCV [V]"])
for T_expt in T_expts:
    for s in SoC:
        logger.info("Running the optimization for SoC: {}...".format(s))
        ocv_expt = ocv_interp(s / 100)
        # Set operating conditions
        model.parameter_values["T_ambient"] = f"{T_expt} [degC]"
        model.parameter_values["SoC_init_cell"] = f"{s}"
        # Set optimized parameters
        if t_opt > 0.2:
            model.parameter_values["f_d_sei_neg"] = "0"
            model.parameter_values["f_cdl_neg"] = "0"
            model.parameter_values["f_cdl_pos"] = "0"
        #
        valid_keys = {}
        input_tables = {}
        I_list = {}
        # Run the optimization study one test at a time

        logger.info(
            f"Filtering HPPC data for the SoC {s} and temperature {T_expt}degC..."
        )
        # Print the contents of the pickle file
        for cell_id in hppc_data.keys():
            for date in hppc_data[cell_id].keys():
                if hppc_data[cell_id][date] is None:
                    continue
                # Filter the data based on the experimental conditions
                for k in hppc_data[cell_id][date][0].keys():
                    if (
                        ocv_expt * 0.995
                        < float(k.split("_")[1].replace("V", ""))
                        < ocv_expt * 1.005
                    ) and (round(float(k.split("_")[2].replace("°C", ""))) == T_expt):
                        if cell_id not in valid_keys:
                            valid_keys[cell_id] = []
                            I_list[cell_id] = []
                        valid_keys[cell_id].append(hppc_data[cell_id][date][0][k])
                        I_list[cell_id].append(float(k.split("_")[0].replace("A", "")))

                # Sort the data based on the current values
                if cell_id in I_list:
                    I_list[cell_id] = [
                        sorted(I_list[cell_id])[i] for i in [0, 1, -2, -1]
                    ]

        if len(valid_keys) == 0:
            logger.error(
                f"No test data available for SoC {s}% and temperature {T_expt}degC. Skipping..."
            )
        else:
            for cell_id in valid_keys:
                logger.info(
                    f"Creating HPPC data table for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                )
                i = 0
                for df in valid_keys[cell_id]:
                    idx_pulse = df[df["Current [A]"].diff().abs() > 1].index[0]
                    if not any(
                        abs(df["Current [A]"].iloc[idx_pulse] - I) <= 0.1
                        for I in I_list[cell_id]
                    ):
                        continue
                    idx_resampled = df[
                        df["Time [s]"].apply(lambda x: x - round(x)) == 0.0
                    ].index
                    idx_first = idx_resampled[idx_resampled > idx_pulse][0]
                    idx_resampled = idx_resampled.append(
                        pd.Index(
                            np.linspace(
                                idx_pulse, idx_first, idx_first - idx_pulse + 1
                            )[0:-1]
                        )
                    ).sort_values()
                    df2 = df.iloc[idx_resampled].reset_index(drop=True)
                    df2 = df2[
                        df2["Time [s]"] <= (t_opt + df2["Time [s]"].iloc[idx_pulse - 1])
                    ]
                    df2 = df2.iloc[idx_pulse - 1 :]
                    df2["Time [s]"] = df2["Time [s]"] - df2["Time [s]"].iloc[0]
                    df2.drop(columns=["Step"]).to_csv(
                        rf"{tmp_path}\HPPC{i+1}.csv", index=False
                    )
                    # Add global optimization features
                    global_opt.add_objective(
                        name=f"glsobj{i+1}",  # Not to be changed
                        input_table=model.input_table_map[f"test_data{i+1}"],
                        time_col="1",
                        use_cols=[
                            ["1"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                        ],
                        col_units=[
                            ["V"],
                            [""],
                            [""],
                            [""],
                            [""],
                            [""],
                            [""],
                            [""],
                            [""],
                        ],
                        model_vars=[
                            [f"V_cell{i+1}"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                            ["0"],
                        ],
                    )
                    input_tables[f"test_data{i+1}"] = rf"{tmp_path}\HPPC{i+1}.csv"
                    i += 1

                # Set up the study with the optimization features
                logger.info(
                    f"Setting up the optimization study for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                )
                hppc_fit = pycomsol.Study(
                    name="time_parameter_estimation",
                    tag="time_parameter_estimation",
                    input_tables=input_tables,
                    output_tables=[
                        "optimization_objective",
                        "parameter_confidence",
                        "parameter_covariance",
                    ],
                    features=[opt],
                    physics=[global_opt],
                )
                # Initialize the SoCs
                logger.info(
                    f"Initializing model SoCs for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                )
                initialize_soc = pycomsol.Study(
                    name="initialize_soc",
                    tag="initialize_soc",
                    input_tables=input_tables,
                    output_tables=["time_probes"],
                )
                sim_optim = pycomsol.Simulation(
                    model,
                    identifier=f"HPPC_T{T_expt}_SoC{s}_Cell_{cell_id}",
                    output_path=output_path,
                )
                try:
                    initialize_soc = sim_optim.solve(
                        studies=initialize_soc,
                        drop_physics=["opt"],
                        logfile=rf"{tmp_path}\COMSOL_{sim_optim.identifier}.log",
                    )
                    out = sim_optim.evaluate(
                        studies=initialize_soc,
                        variables=["SoC_init1", "SoC_init2", "SoC_init3", "SoC_init4"],
                        units=["1", "1", "1", "1"],
                    )
                    # Map soc variables to parameter values
                    for key in out.keys():
                        # Get digit from key string
                        idx = int("".join(filter(str.isdigit, key)))
                        model.parameter_values[f"SoC_init_cell{idx}"] = out[key]

                    # Run the simulation
                    logger.info(
                        f"Running the optimization study for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                    )
                    sol = sim_optim.solve(
                        studies=hppc_fit,
                        logfile=rf"{tmp_path}\COMSOL_{sim_optim.identifier}.log",
                    )

                    for key in hppc_fit.solution.keys():
                        hppc_fit.solution[key].to_csv(
                            rf"{tmp_path}\out_{sim_optim.identifier}_{key}.csv",
                            index=False,
                        )

                    # Verify the optimized parameters
                    idx_min = hppc_fit.solution["optimization_objective"][
                        "Objective"
                    ].idxmin()
                    out_fitted_params = hppc_fit.solution[
                        "optimization_objective"
                    ].drop(columns=["Objective"])

                    # Get the optimized parameters
                    # param_list = [
                    #     col.replace("f_", "") for col in out_fitted_params.columns
                    # ]
                    param_list = [col for col in out_fitted_params.columns]

                    for col in out_fitted_params.columns:
                        model.parameter_values[col] = (
                            f"{out_fitted_params[col].iloc[idx_min]}"
                        )

                    out_params[(cell_id, T_expt, s)] = sim_optim.get_comsol_parameters(
                        param_list
                    )
                    # Write the optimized parameters to an excel file
                    df = pd.DataFrame.from_dict(out_params, orient="index")
                    df.to_excel(rf"{output_path}\optimization_results.xlsx")

                    logger.info(
                        f"Optimization study for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id} completed, running validation..."
                    )

                    # Run the validation
                    hppc_val = pycomsol.Study(
                        name="time_transient",
                        tag="time_transient",
                        input_tables=input_tables,
                        output_tables=[
                            "time_probes",
                        ],
                    )
                    sim_val = pycomsol.Simulation(
                        model,
                        identifier=f"HPPC_T{T_expt}_SoC{s}_Cell_{cell_id}_val",
                        output_path=output_path,
                    )
                    sol_val = sim_val.solve(
                        studies=hppc_val,
                        drop_physics=["opt"],
                        logfile=rf"{tmp_path}\COMSOL_{sim_val.identifier}.log",
                    )
                    for table_name in sol_val.solution.keys():
                        sol_val.solution[table_name].columns = [
                            col.replace("(", "[")
                            for col in sol_val.solution[table_name].columns
                        ]
                        sol_val.solution[table_name].columns = [
                            col.replace(")", "]")
                            for col in sol_val.solution[table_name].columns
                        ]
                        sol_val.solution[table_name].to_csv(
                            rf"{tmp_path}\out_{sim_val.identifier}.csv",
                            index=False,
                        )

                except Exception as e:
                    logger.error(f"Error occurred: {e}")
                    continue

df = pd.DataFrame.from_dict(out_params, orient="index")
df.to_excel(rf"{output_path}\optimization_results.xlsx")
