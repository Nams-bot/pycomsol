import pycomsol
import pandas as pd
from loguru import logger

# Step 0: Set the model root path
root_path = r"C:\Users\ManikMayur\northvolt.com\Simulation and Modeling - Documents\02_Projects\08_VCC_GPA_A\07_Cell_Electrochemical\B1"
# Step 1: Locate the COMSOL model file
model_path = rf"{root_path}\02_Process\01_Parametrisation\HPPC\LIB_FullCell_HPPC_MultiObj_CO240511.mph"
tmp_path = rf"{root_path}\02_Process\01_Parametrisation\HPPC\tmp"
param_filepath = rf"{root_path}\01_Input\GPA-A_B1_DFN-Parameters.xlsx"

# Step 4: Read EIS data from pickle file
logger.info("Reading HPPC test data...")
hppc_path = rf"{root_path}\01_Input\Test_Data\Data_GPA-A_B1_HPPC_240511.pickle"
hppc_data = pd.read_pickle(hppc_path)

# Load the model
model = pycomsol.DFN(param_filepath, model_path=model_path)

# Optimization features can be controlled
# using the optimization features class
opt = pycomsol.OptimizationFeatures(name="lsqo")

opt.add_parameter("f_d_sei_neg", 0.6, 1, -1, 1)
opt.add_parameter("f_k_neg", -0.3, 1, -1, 1)
opt.add_parameter("f_k_pos", -0.2, 1, -1, 1)
opt.add_parameter("f_nm_neg", -0.1, 1, -1, 1)
opt.add_parameter("f_nm_pos", -0.5, 1, -1, 1)
opt.add_parameter("f_DLi_neg", 1.5, 3, -3, 3)
opt.add_parameter("f_DLi_pos", 0.5, 1, -1, 1)

# Using global optimization physics class
# to define the objective functions
global_opt = pycomsol.GlobalOptimization(name="opt")

global_opt.add_objective(
    name="glsobj1",  # Not to be changed
    input_table=model.input_table_map["test_hppc_data1"],
    time_col="1",
    use_cols=[["1"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
    col_units=[["V"], [""], [""], [""], [""], [""], [""], [""]],
    model_vars=[["V_cell"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
)

global_opt.add_objective(
    name="glsobj2",  # Not to be changed
    input_table=model.input_table_map["test_hppc_data2"],
    time_col="1",
    use_cols=[["1"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
    col_units=[["V"], [""], [""], [""], [""], [""], [""], [""]],
    model_vars=[["V_cell2"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
)

# Set up the study with the optimization features
hppc_fit = pycomsol.Study(
    name="time_parameter_estimation",
    tag="time_parameter_estimation",
    input_tables={
        "test_hppc_data1": rf"{tmp_path}\HPPC1.csv",
        "test_hppc_data2": rf"{tmp_path}\HPPC2.csv",
    },
    output_tables=["standard_probe"],
    features=[opt],
    physics=[global_opt],
)

sim = pycomsol.Simulation(model)

sol = sim.solve(studies=hppc_fit, logfile="COMSOL_HPPC.log")
