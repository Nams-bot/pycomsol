import pycomsol


# Setp 0: Set the model root path
root_path = r"C:\Users\ManikMayur\northvolt.com\Simulation and Modeling - Documents\02_Projects\08_VCC_GPA_A\07_Cell_Electrochemical\B1"
# Step 1: Locate the COMSOL model file
model_path = rf"{root_path}\02_Process\01_Parametrisation\LIB_FullCell_HPPC_MultiObj_CO240511.mph"

param_filepath = rf"{root_path}\01_Input\GPA-A_B1_DFN-Parameters.xlsx"
model = pycomsol.DFN(param_filepath)

my_first_study = pycomsol.Study(
    name="my_unique_study_name",
    tag="time_transient",
    input_tables={"pulse_data": "path_to_input_csv"},
    output_tables=["time_probes"],
)

sim = pycomsol.Simulation(model)
sol = sim.solve(studies=my_first_study)
