import glob
import pycomsol
import pandas as pd
from loguru import logger
from datetime import date
import os

# Step 0: Set the model root path
root_path = rf"C:\Users\{os.getlogin()}\northvolt.com\Simulation and Modeling - Documents\02_Projects\13_Scania_PPE_CV_Gen2\04_Cell_Electrochemical\B0"

# Step 1: Locate the COMSOL model file and setup paths
today = date.today().strftime("%Y%m%d")
model_path = rf"{root_path}\01_Input\Models\LIB_FullCell_HPPC_MultiObj_CO241205.mph"
param_filepath = rf"{root_path}\01_Input\PPE-CV-GEN2_B0_DFN-Parameters_v2.xlsx"
test_path = rf"{root_path}\01_Input\Test_Data\Model_Validation"
output_path = rf"{root_path}\02_Process\03_Validation\output_{today}"
if not os.path.exists(output_path):
    os.makedirs(output_path)
tmp_path = rf"{output_path}\tmp"
if not os.path.exists(tmp_path):
    os.makedirs(tmp_path)

# Step 2: Set the validation test conditions
validation_test = {
    # 1: {"type": "POCV", "temp": 25, "soc": 100},
    # 2: {"type": "RPT", "temp": 25, "soc": 100},
    # 3: {"type": "US06", "temp": 25, "soc": 85},
    # 4: {"type": "US06", "temp": 25, "soc": 35},
    # 5: {"type": "ART", "temp": 25, "soc": 15},
    6: {"type": "MAN1", "temp": 25, "soc": 95},
    # 7: {"type": "GITT", "temp": 35, "soc": 100},
    # 8: {"type": "US06", "temp": 40, "soc": 85},
    # 9: {"type": "US06", "temp": 40, "soc": 35},
    # 10: {"type": "ART", "temp": 40, "soc": 15},
    # 11: {"type": "ART", "temp": 40, "soc": 95},
    # 12: {"type": "US06", "temp": -10, "soc": 85},
    # 13: {"type": "US06", "temp": -10, "soc": 35},
    # 14: {"type": "ART", "temp": -10, "soc": 15},
    # 15: {"type": "ART", "temp": -10, "soc": 95},
    # 16: {"type": "FC", "temp": 25, "soc": 10},
    # 17: {"type": "FC", "temp": 35, "soc": 10},
}

file_list = glob.glob(rf"{test_path}\*.csv")

if len(file_list) == 0:
    logger.error("No files found in the test data folder")
    exit()

# Step 3: Load the model
logger.info(f"Loading model from {model_path}")
model = pycomsol.DFN(param_filepath, model_path=model_path)

# Step 4: Run each test condition one at a time
for idx, test in validation_test.items():
    filtered_files = [
        file
        for file in file_list
        if all(
            word in file for word in [test["type"], str(test["temp"]), str(test["soc"])]
        )
    ]
    if len(filtered_files) == 0:
        logger.error(
            f"No files found for {test["type"]}, {test["temp"]} degC, {test["soc"]}% SoC"
        )
        continue

    # Create file list for the test data
    input_files = {}
    idx = 1
    t_max = 3600  # Default value
    for file in sorted(filtered_files):
        logger.info(f"Adding {file} to the input files")
        input_files[f"test_data{idx}"] = file
        data = pd.read_csv(file)
        t_max = data["Time [s]"].max()
        idx += 1
        if idx > 4:
            break

    # Set the operating conditions and the study parameters
    model.parameter_values["T_ambient"] = f"{test["temp"]} [degC]"
    model.parameter_values["t_max"] = f"{t_max} [s]"

    # Define the study
    test_val = pycomsol.Study(
        name="time_transient",
        tag="time_transient",
        input_tables=input_files,
        output_tables=["time_probes"],
    )
    initialize_soc = pycomsol.Study(
        name="initialize_soc",
        tag="initialize_soc",
        input_tables=input_files,
        output_tables=["time_probes"],
    )

    # Initialize the socs
    logger.info(
        f"Initializing model SoCs for {test["type"]} at {test["temp"]} degC and {test["soc"]}% SoC"
    )

    sim_val = pycomsol.Simulation(
        model,
        identifier=f"{test["type"]}_T{test["temp"]}_SoC{test["soc"]}_val",
        output_path=output_path,
    )
    initialize_soc = sim_val.solve(
        studies=initialize_soc,
        drop_physics=["opt"],
        logfile=rf"{tmp_path}\COMSOL_{sim_val.identifier}.log",
    )
    out = sim_val.evaluate(
        studies=initialize_soc,
        variables=["SoC_init1", "SoC_init2", "SoC_init3", "SoC_init4"],
        units=["1", "1", "1", "1"],
    )
    # Map soc variables to parameter values
    for key in out.keys():
        # Get digit from key string
        idx = int("".join(filter(str.isdigit, key)))
        model.parameter_values[f"SoC_init_cell{idx}"] = out[key]

    # Solve the model
    logger.info(
        f"Solving model for {test["type"]} at {test["temp"]} degC and {test["soc"]}% SoC"
    )
    sol_val = sim_val.solve(
        studies=test_val,
        drop_physics=["opt"],
        logfile=rf"{tmp_path}\COMSOL_{sim_val.identifier}.log",
    )

    # Post-process the results
    logger.info("Post-processing the results")
    for key in test_val.solution.keys():
        test_val.solution[key].to_csv(
            rf"{tmp_path}\out_{key}_{sim_val.identifier}.csv", index=False
        )
