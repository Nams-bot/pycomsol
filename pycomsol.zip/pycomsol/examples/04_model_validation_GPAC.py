import glob
import pycomsol
import pandas as pd
from loguru import logger
from datetime import date
import os
from pathlib import Path
import multiprocessing
from pycomsol.utils import progress_bar

# Step 0: Set the model root path
# stop_event = multiprocessing.Event()

root_path = Path(
    rf"C:\Users\{os.getlogin()}\northvolt.com\Simulation and Modeling - Documents\02_Projects\11_VCC_GPA_C\02_Process\07_Cell_Electrochemical\B0.1-RDOE"
)

# Step 1: Locate the COMSOL model file and setup paths
today = date.today().strftime("%Y%m%d")
input_path = root_path / "01_Input"
model_path = input_path / "Models" / "LIB_FullCell_HPPC_MultiObj_CO250205.mph"
param_filepath = input_path / "PPE-CV-GEN2_B0_DFN-Parameters_v4.xlsx"
test_path = input_path / "Test_Data" / "Model_Validation"
# test_path = input_path / "Test_Data" / "Model_Parameterization"
output_path = root_path / "02_Process" / "03_Validation" / f"output_{today}"

if not output_path.exists():
    output_path.mkdir()
else:
    # Create a new output folder if one already exists
    idx = 1
    while output_path.exists():
        output_path = (
            root_path / "02_Process" / "03_Validation" / f"output_{today}_{idx}"
        )
        idx += 1
    output_path.mkdir()  # Create the new output folder

tmp_path = output_path / "tmp"
if not tmp_path.exists():
    tmp_path.mkdir()


# Copy the parameter file to the output folder using pathlib
param_out = Path(output_path) / param_filepath.name
param_out.write_bytes(param_filepath.read_bytes())
model_out = Path(output_path) / model_path.name
model_out.write_bytes(model_path.read_bytes())

# Step 2: Set the validation test conditions
validation_test = {
    # 1: {"type": "POCV", "temp": 25, "soc": 100},
    # 2: {"type": "RPT", "temp": 25, "soc": 100},
    # 3: {"type": "GITT", "temp": 35, "soc": 100},
    # 4: {"type": "US06", "temp": 25, "soc": 35},
    # 5: {"type": "ART", "temp": 25, "soc": 15},
    # 6: {"type": "MAN1", "temp": 25, "soc": 95},
    # 7: {"type": "MAN4", "temp": 25, "soc": 90},
    # 8: {"type": "MAN4", "temp": 40, "soc": 70},
    # 9: {"type": "US06", "temp": 40, "soc": 35},
     10: {"type": "ART", "temp": 25, "soc": 60},
    # 11: {"type": "ART", "temp": 40, "soc": 95},
    # 12: {"type": "US06", "temp": -10, "soc": 85},
    # 13: {"type": "US06", "temp": -10, "soc": 35},
    # 14: {"type": "ART", "temp": -10, "soc": 15},
    # 15: {"type": "ART", "temp": -10, "soc": 95},
    # 16: {"type": "FC", "temp": 25, "soc": 10},
    # 17: {"type": "FC", "temp": 35, "soc": 10},
}

file_list = glob.glob(rf"{test_path}\*.csv")

if len(file_list) == 0:
    logger.error("No files found in the test data folder")
    exit()

# Step 3: Load the model
logger.info(f"Loading model from {model_path}")
model = pycomsol.DFN(param_filepath, model_path=model_path)

# Step 4: Run each test condition one at a time
for idx, test in validation_test.items():
    filtered_files = [
        file
        for file in file_list
        if all(
            word in file for word in [test["type"], str(test["temp"]), str(test["soc"])]
        )
    ]
    if len(filtered_files) == 0:
        logger.error(
            f"No files found for {test["type"]}, {test["temp"]} degC, {test["soc"]}% SoC"
        )
        continue

    # Create file list for the test data
    input_files = {}
    idx = 1
    t_max = 3600  # Default value
    for file in sorted(filtered_files):
        logger.info(f"Adding {file} to the input files")
        input_files[f"test_data{idx}"] = file
        data = pd.read_csv(file)
        t_max = data["Time [s]"].max()
        data["Time [s]"] = data["Time [s]"] - data["Time [s]"].min()
        data.to_csv(file, index=False)
        idx += 1
        if idx > 4:
            break

    # Set the operating conditions and the study parameters
    model.parameter_values["T_ambient"] = f"{test["temp"]} [degC]"
    model.parameter_values["t_max"] = f"{t_max} [s]"
    model.parameter_values["F_area_loss"] = "0.04"
    test_val = pycomsol.Study(
        name="time_transient",
        tag="time_transient",
        input_tables=input_files,
        output_tables=[
            "time_probes",
        ],
    )

    # Initialize the SoCs
    logger.info(f"Initializing model SoCs ...")
    initialize_soc = pycomsol.Study(
        name="initialize_soc",
        tag="initialize_soc",
        input_tables=input_files,
        output_tables=["time_probes"],
    )
    sim_val = pycomsol.Simulation(
        model,
        identifier=f"{test["type"]}_T{test["temp"]}_SoC{test["soc"]}_val",
        output_path=output_path,
    )
    initialize_soc = sim_val.solve(
        studies=initialize_soc,
        drop_physics=[("comp1", "opt"), ("comp2", "opt2")],
        logfile=rf"{tmp_path}\COMSOL_{sim_val.identifier}.log",
    )
    out = sim_val.evaluate(
        studies=initialize_soc,
        variables=["SoC_init1", "SoC_init2", "SoC_init3", "SoC_init4"],
        units=["1", "1", "1", "1"],
    )
    # Map soc variables to parameter values
    for key in out.keys():
        # Get digit from key string
        idx = int("".join(filter(str.isdigit, key)))
        model.parameter_values[f"SoC_init_cell{idx}"] = out[key]

    # Solve the model
    logger.info(
        f"Solving model for {test["type"]} at {test["temp"]} degC and {test["soc"]}% SoC"
    )
    # Create a progress bar process
    # progress_bar_process = multiprocessing.Process(
    #     target=progress_bar,
    #     args=(stop_event, rf"{tmp_path}\COMSOL_{sim_val.identifier}.log", 60),
    # )
    sol_val = sim_val.solve(
        studies=test_val,
        drop_physics=[("comp1", "opt"), ("comp2", "opt2")],
        logfile=rf"{tmp_path}\COMSOL_{sim_val.identifier}.log",
        # stop_event=stop_event,
    )
    # progress_bar_process.join()
    # Post-process the results
    logger.info("Post-processing the results")
    for key in test_val.solution.keys():
        test_val.solution[key].to_csv(
            rf"{tmp_path}\out_{key}_{sim_val.identifier}.csv", index=False
        )
