import time
import re
import multiprocessing
import os
from rich.progress import Progress, BarColumn, TextColumn

LOG_FILE = r"C:\Users\ValidationSimulation\northvolt.com\Simulation and Modeling - Documents\02_Projects\13_Scania_PPE_CV_Gen2\02_Process\04_Cell_Electrochemical\B0\02_Process\03_Validation\output_20250208_8\tmp\COMSOL_MAN4_T25_SoC90_val.log"
TOTAL_STEPS = 100  # Assuming progress is from 0 to 100%
CHECK_INTERVAL = 30  # Change this to adjust the frequency (seconds)


def extract_progress_from_log(log_file=LOG_FILE):
    """Reads the latest progress percentage from the log file."""
    if not os.path.exists(log_file):
        return 0  # Default to 0% if file doesn't exist

    with open(log_file, "r") as f:
        lines = f.readlines()

    # Find the last occurrence of the progress percentage
    for line in reversed(lines):
        match = re.search(r"Current Progress:\s*(\d+)\s*%", line)
        if match:
            return int(match.group(1))  # Extract progress value
    return 0  # Default if no progress found


def progress_bar(stop_event, check_interval):
    """Monitors the log file and updates the progress bar at the given interval."""
    with Progress(
        TextColumn("[cyan]{task.description}"),
        BarColumn(),
        TextColumn("[green]{task.percentage:>3.0f}%"),
    ) as progress:
        task = progress.add_task("Processing...", total=TOTAL_STEPS)

        while not stop_event.is_set():
            current_progress = extract_progress_from_log()
            progress.update(task, completed=min(current_progress, TOTAL_STEPS))

            if current_progress >= TOTAL_STEPS:  # Stop when we reach 100%
                break

            time.sleep(check_interval)  # Wait for the next check

        # Ensure progress bar completes fully
        progress.update(task, completed=TOTAL_STEPS)


def main_task(stop_event):
    """Simulates a process writing progress logs."""
    with open(LOG_FILE, "w") as log_file:
        for i in range(0, 4000, 5):  # Increment progress in steps of 5%
            # log_file.write(
            #     f"--------   Current Progress:  {i} % - Assembling matrices\n"
            # )
            # log_file.flush()  # Ensure immediate log update
            time.sleep(5)  # Simulate work
    stop_event.set()  # Stop the progress bar


if __name__ == "__main__":
    stop_event = multiprocessing.Event()

    # Start progress bar in a separate process
    progress_process = multiprocessing.Process(
        target=progress_bar, args=(stop_event, CHECK_INTERVAL)
    )
    progress_process.start()

    # Run the main task
    main_task(stop_event)

    # Wait for the progress process to finish
    progress_process.join()
