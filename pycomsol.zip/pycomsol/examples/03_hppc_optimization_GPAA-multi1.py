import pycomsol
import pandas as pd
from loguru import logger
from scipy.interpolate import PchipInterpolator
from datetime import date
import numpy as np
import os

# Step 0: Set the model root path
root_path = rf"C:\Users\{os.getlogin()}\northvolt.com\Simulation and Modeling - Documents\02_Projects\08_VCC_GPA_A\07_Cell_Electrochemical\B1"
# Step 1: Locate the COMSOL model file
today = date.today().strftime("%Y%m%d")
model_path = rf"{root_path}\01_Input\Models\LIB_FullCell_HPPC_MultiObj_CO240927.mph"
param_filepath = rf"{root_path}\01_Input\GPA-A_B1_DFN-Parameters_v3.xlsx"

# Step 4: Read test data from pickle file
logger.info("Reading HPPC test data...")
ocv_path = rf"{root_path}\01_Input\OCV\cell\GPA-A_B1-398_gOCV_balanced.csv"
hppc_path = rf"{root_path}\01_Input\Test_Data\Data_GPA-A_B1_HPPC_240511.pickle"
hppc_data = pd.read_pickle(hppc_path)

output_path = rf"{root_path}\02_Process\01_Parametrisation\HPPC\output_{today}_1"

if not os.path.exists(output_path):
    os.makedirs(output_path)
tmp_path = rf"{output_path}\tmp"
if not os.path.exists(tmp_path):
    os.makedirs(tmp_path)


# Load the model
model = pycomsol.DFN(param_filepath, model_path=model_path)

# Optimization features can be controlled
# using the optimization features class
opt = pycomsol.OptimizationFeatures(name="lsqo")

# opt.add_parameter()
optim_parameters = {
    # "f_d_sei_neg": [1, 2, -2, 2],
    "f_k_neg": [-9, 10, -10, 0],
    "f_k_pos": [-9, 10, -10, 0],
    # "f_cdl_neg": [0, 1, -1, 1],
    # "f_cdl_pos": [0, 1, -1, 1],
    # "nm_neg": [10, 10, 5, 25],
    # "nm_pos": [18, 10, 5, 25],
    "f_DLi_neg": [-12, 14, -14, 0],
    "f_DLi_pos": [-12, 14, -14, 0],
    # "f_r_neg": [0, 0.01, -0.02, 0.02],
    # "f_r_pos": [0, 0.01, -0.02, 0.02],
}
for key, value in optim_parameters.items():
    opt.add_parameter(key, *value)

# Using global optimization physics class
# to define the objective functions
global_opt = pycomsol.GlobalOptimization(name="opt")

global_opt.add_objective(
    name="glsobj1",  # Not to be changed
    input_table=model.input_table_map["test_data1"],
    time_col="1",
    use_cols=[["1"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
    col_units=[["V"], [""], [""], [""], [""], [""], [""], [""]],
    model_vars=[["V_cell"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
)

global_opt.add_objective(
    name="glsobj2",  # Not to be changed
    input_table=model.input_table_map["test_data2"],
    time_col="1",
    use_cols=[["1"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
    col_units=[["V"], [""], [""], [""], [""], [""], [""], [""]],
    model_vars=[["V_cell2"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
)

# Step 6: Run the optimization
t_opt = 90  # 0.2  # seconds
# SoC = [90]
SoC = [100, 90, 80, 70, 60]
T_expts = [25, 40]

out_params = {}
# Get global variables
ocv_table = pd.read_csv(ocv_path)
ocv_interp = PchipInterpolator(ocv_table["DoD [%]"].values, ocv_table["gOCV [V]"])
for T_expt in T_expts:
    for s in SoC:
        logger.info("Running the optimization for SoC: {}...".format(s))
        ocv_expt = ocv_interp(100 - s)
        # Set operating conditions
        model.parameter_values["T_ambient"] = f"{T_expt} [degC]"
        model.parameter_values["SoC_init_cell"] = f"{s/100}"
        valid_keys = {}
        # Run the optimization study one test at a time

        logger.info(
            f"Filtering HPPC data for the SoC {s} and temperature {T_expt}degC..."
        )
        for cell_id in hppc_data.keys():
            for date in hppc_data[cell_id].keys():
                for k in hppc_data[cell_id][date][0].keys():
                    if (
                        ocv_expt * 0.995
                        < float(k[1].replace("V", ""))
                        < ocv_expt * 1.005
                    ) and (round(float(k[2].replace("°C", ""))) == T_expt):
                        if cell_id not in valid_keys:
                            valid_keys[cell_id] = []
                        valid_keys[cell_id].append(hppc_data[cell_id][date][0][k])

        if len(valid_keys) == 0:
            logger.error(
                f"No test data available for SoC {s}% and temperature {T_expt}degC. Skipping..."
            )
        else:
            for cell_id in valid_keys:
                logger.info(
                    f"Creating HPPC data table for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                )
                i = 0
                for df in valid_keys[cell_id]:
                    idx_pulse = df[df["Current (A)"].diff().abs() > 1].index

                    idx_resampled = df[
                        df["Time (s)"].apply(lambda x: x - round(x)) == 0.0
                    ].index
                    idx_first = idx_resampled[idx_resampled > idx_pulse[0]][0]
                    idx_resampled = idx_resampled.append(
                        pd.Index(
                            np.linspace(
                                idx_pulse[0], idx_first, idx_first - idx_pulse[0] + 1
                            )[0:-1]
                        )
                    ).sort_values()
                    df2 = df.iloc[idx_resampled].reset_index(drop=True)
                    df2 = df2[df2["Time (s)"] <= t_opt]
                    df2.drop(columns=["Step"]).to_csv(
                        rf"{tmp_path}\HPPC{i+1}.csv", index=False
                    )
                    i += 1

                # Set up the study with the optimization features
                logger.info(
                    f"Setting up the optimization study for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                )
                hppc_fit = pycomsol.Study(
                    name="time_parameter_estimation",
                    tag="time_parameter_estimation",
                    input_tables={
                        "test_data1": rf"{tmp_path}\HPPC1.csv",
                        "test_data2": rf"{tmp_path}\HPPC2.csv",
                    },
                    output_tables=[
                        "optimization_objective",
                        "parameter_confidence",
                        "parameter_covariance",
                    ],
                    features=[opt],
                    physics=[global_opt],
                )

                # Run the simulation
                logger.info(
                    f"Running the optimization study for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                )

                sim_optim = pycomsol.Simulation(
                    model,
                    identifier=f"HPPC_T{T_expt}_SoC{s}_Cell_{cell_id}",
                    output_path=output_path,
                )
                try:
                    sol = sim_optim.solve(
                        studies=hppc_fit,
                        logfile=rf"{tmp_path}\COMSOL_{sim_optim.identifier}.log",
                    )

                    for key in hppc_fit.solution.keys():
                        hppc_fit.solution[key].to_csv(
                            rf"{tmp_path}\out_{sim_optim.identifier}_{key}.csv",
                            index=False,
                        )

                    # Verify the optimized parameters
                    idx_min = hppc_fit.solution["optimization_objective"][
                        "Objective"
                    ].idxmin()
                    out_fitted_params = hppc_fit.solution[
                        "optimization_objective"
                    ].drop(columns=["Objective"])

                    # Get the optimized parameters
                    param_list = [
                        col.replace("f_", "") for col in out_fitted_params.columns
                    ]

                    for col in out_fitted_params.columns:
                        model.parameter_values[col] = (
                            f"{out_fitted_params[col].iloc[idx_min]}"
                        )

                    out_params[(cell_id, T_expt, s)] = sim_optim.get_comsol_parameters(
                        param_list
                    )

                    logger.info(
                        f"Optimization study for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id} completed, running validation..."
                    )

                    # Run the validation
                    hppc_val = pycomsol.Study(
                        name="time_transient",
                        tag="time_transient",
                        input_tables={
                            "test_data1": rf"{tmp_path}\HPPC1.csv",
                            "test_data2": rf"{tmp_path}\HPPC2.csv",
                        },
                        output_tables=[
                            "time_probes",
                        ],
                    )
                    sim_val = pycomsol.Simulation(
                        model,
                        identifier=f"HPPC_T{T_expt}_SoC{s}_Cell_{cell_id}_val",
                        output_path=output_path,
                    )
                    sol_val = sim_val.solve(
                        studies=hppc_val,
                        drop_physics=["opt"],
                        logfile=rf"{tmp_path}\COMSOL_{sim_val.identifier}.log",
                    )
                    for study_name in sol_val.keys():
                        for table_name in sol_val[study_name].solution.keys():
                            sol_val[study_name].solution[table_name].columns = [
                                col.replace("(", "[")
                                for col in sol_val[study_name]
                                .solution[table_name]
                                .columns
                            ]
                            sol_val[study_name].solution[table_name].columns = [
                                col.replace(")", "]")
                                for col in sol_val[study_name]
                                .solution[table_name]
                                .columns
                            ]
                            sol_val[study_name].solution[table_name].to_csv(
                                rf"{tmp_path}\out_{sim_val.identifier}_{study_name}_{table_name}.csv",
                                index=False,
                            )

                except Exception as e:
                    logger.error(f"Error occurred: {e}")
                    continue

df = pd.DataFrame.from_dict(out_params, orient="index")
df.to_excel(rf"{output_path}\optimization_results.xlsx")
