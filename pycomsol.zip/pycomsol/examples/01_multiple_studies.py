import pycomsol

param_filepath = "path_to_parameter_file"
model = pycomsol.DFN(param_filepath)

study1 = pycomsol.Study(
    name="my_unique_study_name",
    tag="time_transient",
    input_tables={"pulse_data": "path_to_input_csv"},
    output_tables=["time_probes"],
)

study2 = pycomsol.Study(
    name="another_study",
    tag="frequency_transient",
    input_tables={"eis_data": "path_to_input_eis_csv"},
    output_tables=["eis_probe"],
)

studies = [study1, study2]

sim = pycomsol.Simulation(model)
sol = sim.solve(studies=studies)
