import pycomsol
import pandas as pd
from loguru import logger
from scipy.interpolate import PchipInterpolator
from datetime import date
import numpy as np
import os
from pathlib import Path

####################################################################################################
# Step 0: Define the optimization parameters
####################################################################################################
test_type = "HPPC"
t_opt = 0.2  # [s] Optimization time
SoC = [50, 40, 30, 20, 10]  # [%] SoC values
T_expts = [25]  # [degC] Temperature values

####################################################################################################
# Step 1: Setup input and output files and paths
####################################################################################################

# Step 1.1: Set the model root path
root_path = Path(
    rf"C:\Users\{os.getlogin()}\northvolt.com\Simulation and Modeling - Documents\02_Projects\13_Scania_PPE_CV_Gen2\02_Process\04_Cell_Electrochemical\B0"
)
input_path = root_path / "01_Input"

# Step 1.2: Locate the COMSOL model and parameter file
model_path = input_path / "Models" / "LIB_FullCell_HPPC_MultiObj_CO250318.mph"
param_filepath = input_path / "PPE-CV-GEN2_B0_DFN-Parameters_v11.3.xlsx"

# Step 1.3: Read the OCV data
ocv_path = input_path / "OCV" / "Cell" / "OCV_balanced_PPE-CV-GEN2_GITT.csv"
ocv_table = pd.read_csv(ocv_path)
ocv_interp = PchipInterpolator(ocv_table["SOC [1]"].values, ocv_table["OCV [V]"])

# Step 1.4: Read test data from pickle file
logger.info(f"Reading {test_type} test data...")
test_path = input_path / "Test_Data" / "Data_PPE_CV_GEN2_B0_HPPC_241029.pickle"
test_data = pd.read_pickle(test_path.as_posix())

# Step 1.5: Set the output path
today = date.today().strftime("%Y%m%d")
output_path = (
    root_path
    / "02_Process"
    / "01_Parametrisation"
    / test_type
    / f"out_{today}_{'_'.join(map(str, T_expts))}degC_{t_opt}s_2"
)

if not output_path.exists():
    output_path.mkdir()
else:
    # Create a new output folder if one already exists
    idx = 1
    while output_path.exists():
        output_path = (
            root_path
            / "02_Process"
            / "01_Parametrisation"
            / test_type
            / f"out_{today}_{'_'.join(map(str, T_expts))}_degC_{t_opt}s_2_{idx}"
        )
        idx += 1
    output_path.mkdir()  # Create the new output folder

tmp_path = output_path / "tmp"
if not tmp_path.exists():
    tmp_path.mkdir()


# Copy the parameter file to the output folder using pathlib
param_out = Path(output_path) / param_filepath.name
param_out.write_bytes(param_filepath.read_bytes())
model_out = Path(output_path) / model_path.name
model_out.write_bytes(model_path.read_bytes())

# Save the current Python file in the output_path
current_file_path = Path(__file__)
destination_file_path = Path(output_path) / current_file_path.name
destination_file_path.write_text(current_file_path.read_text())

####################################################################################################
# Step 2: Set up the model and optimization features
####################################################################################################

# Atep 2.1: Load the model
model = pycomsol.DFN(param_filepath, model_path=model_path)

# Step 2.2: Set up the optimization features
opt = pycomsol.OptimizationFeatures(name="lsqo")

optim_parameters = {
    # "f_d_sei_neg": [0, 2, -2, 2],
    "f_k_neg": [0, 8, -8, 8],
    "f_k_pos": [0, 8, -8, 8],
    "f_cdl_neg": [0, 1, -1, 1],
    "f_cdl_pos": [0, 1, -1, 1],
    "a_neg": [0.5, 1, 0.1, 0.9],
    "a_pos": [0.5, 1, 0.1, 0.9],
    # "nm_neg": [10, 10, 5, 25],
    # "nm_pos": [18, 10, 5, 25],
    # "f_DLi_neg": [0, 2, -2, 2],
    # "f_DLi_pos": [0, 2, -2, 2],
    # "f_r_neg": [0, 0.01, -0.02, 0.02],
    # "f_r_pos": [0, 0.01, -0.02, 0.02],
}
for key, value in optim_parameters.items():
    opt.add_parameter(key, *value)

# Step 2.3: Using global optimization physics class
# to define the objective functions
global_opt = pycomsol.GlobalOptimization(name="opt")

####################################################################################################
# Step 3: Run the optimization study
####################################################################################################

# Step 3.1: Initialize the container for output parameters
out_params = {}

# Step 3.2: Run the optimization study for each SoC and temperature
for T_expt in T_expts:
    for s in SoC:
        # Set operating conditions
        model.parameter_values["T_ambient"] = f"{T_expt} [degC]"
        model.parameter_values["SoC_init_cell"] = f"{s}"

        ocv_expt = ocv_interp(s / 100)  # [V] Experimental OCV at the SoC
        #
        valid_keys = {}
        input_tables = {}
        I_list = {}

        logger.info(
            f"Filtering {test_type} data for the SoC {s} and temperature {T_expt}degC..."
        )

        # Filter test data from pickle file based on the SoC and temperature
        for cell_id in test_data.keys():
            for date in test_data[cell_id].keys():
                if test_data[cell_id][date] is None:
                    continue
                # Filter the data based on the experimental conditions
                for k in test_data[cell_id][date][0].keys():
                    if (
                        ocv_expt * 0.995
                        < float(k.split("_")[1].replace("V", ""))
                        < ocv_expt * 1.005
                    ) and (round(float(k.split("_")[2].replace("°C", ""))) == T_expt):
                        if cell_id not in valid_keys:
                            valid_keys[cell_id] = []
                            I_list[cell_id] = []
                        valid_keys[cell_id].append(test_data[cell_id][date][0][k])
                        I_list[cell_id].append(float(k.split("_")[0].replace("A", "")))

                # Sort the data based on the current values
                if cell_id in I_list:
                    I_list[cell_id] = [
                        sorted(I_list[cell_id])[i] for i in [0, 1, -2, -1]
                    ]

        # Delete the old existing model input test data files in the temporary folder
        for file in tmp_path.glob(f"{test_type}*"):
            file.unlink()

        # Create the input test data files for the optimization
        if len(valid_keys) == 0:
            logger.error(
                f"No test data available for SoC {s}% and temperature {T_expt}degC. Skipping..."
            )
            continue
        else:
            for cell_id in valid_keys:
                logger.info(
                    f"Creating {test_type} data table for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                )
                i = 0
                for df in valid_keys[cell_id]:
                    idx_pulse = df[df["Current [A]"].diff().abs() > 1].index[0]
                    if not any(
                        abs(df["Current [A]"].iloc[idx_pulse] - I) <= 0.1
                        for I in I_list[cell_id]
                    ):
                        continue
                    df2 = df.iloc[idx_pulse - 1 :].reset_index(drop=True)
                    df2["Time [s]"] -= df2["Time [s]"].iloc[0]
                    df2 = df2[df2["Time [s]"] <= t_opt]
                    df2["Time [s]"] += 1
                    df2.loc[-1] = df2.iloc[0]
                    df2.index = df2.index + 1
                    df2.sort_index(inplace=True)
                    df2.loc[0, "Time [s]"] = 0
                    df2 = pycomsol.data_subsample(
                        df2.drop(columns=["Step"]),
                        col_t="Time [s]",
                        col_v="Voltage [V]",
                    )
                    df2.to_csv(tmp_path / f"{test_type}{i+1}.csv", index=False)
                    # Add global optimization features
                    # fmt: off
                    global_opt.add_objective(
                        name=f"glsobj{i+1}",  # Not to be changed
                        input_table=model.input_table_map[f"test_data{i+1}"],
                        time_col="1",
                        use_cols=[ ["1"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
                        col_units=[ ["V"], [""], [""], [""], [""], [""], [""], [""], [""]],
                        model_vars=[ [f"V_cell{i+1}"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"], ["0"]],
                    )
                    # fmt: on
                    input_tables[f"test_data{i+1}"] = (
                        tmp_path / f"{test_type}{i+1}.csv"
                    ).as_posix()
                    i += 1

                # Initialize the SoCs
                logger.info(
                    f"Initializing model SoCs for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                )
                initialize_soc = pycomsol.Study(
                    name="initialize_soc",
                    tag="initialize_soc",
                    input_tables=input_tables,
                    output_tables=["time_probes"],
                )
                sim_optim = pycomsol.Simulation(
                    model,
                    identifier=f"{test_type}_T{T_expt}_SoC{s}_Cell_{cell_id}",
                    output_path=output_path,
                )
                try:
                    initialize_soc = sim_optim.solve(
                        studies=initialize_soc,
                        drop_physics=[("comp1", "opt"), ("comp2", "opt2")],
                        logfile=(
                            tmp_path / f"COMSOL_{sim_optim.identifier}.log"
                        ).as_posix(),
                    )
                    out = sim_optim.evaluate(
                        studies=initialize_soc,
                        variables=["SoC_init1", "SoC_init2", "SoC_init3", "SoC_init4"],
                        units=["1", "1", "1", "1"],
                    )
                    # Map soc variables to parameter values
                    act_init_soc = []
                    xLi_init_pos = []
                    xLi_init_neg = []
                    for key in out.keys():
                        # Get digit from key string
                        idx = int("".join(filter(str.isdigit, key)))
                        model.parameter_values[f"SoC_init_cell{idx}"] = out[key]
                        act_init_soc.append(out[key])
                        xLi_init_pos.append(
                            out[key]
                            * (
                                float(model.parameter_values["xLi_100_pos"])
                                - float(model.parameter_values["xLi_0_pos"])
                            )
                            + float(model.parameter_values["xLi_0_pos"])
                        )
                        xLi_init_neg.append(
                            out[key]
                            * (
                                float(model.parameter_values["xLi_100_neg"])
                                - float(model.parameter_values["xLi_0_neg"])
                            )
                            + float(model.parameter_values["xLi_0_neg"])
                        )

                    # Set up the study with the optimization features
                    logger.info(
                        f"Setting up the optimization study for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                    )
                    test_fit = pycomsol.Study(
                        name="time_parameter_estimation",
                        tag="time_parameter_estimation",
                        input_tables=input_tables,
                        output_tables=[
                            "optimization_objective",
                            "parameter_confidence",
                            "parameter_covariance",
                        ],
                        features=[opt],
                        physics=[global_opt],
                    )
                    # Run the simulation
                    logger.info(
                        f"Running the optimization study for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id}..."
                    )
                    sol = sim_optim.solve(
                        studies=test_fit,
                        drop_physics=[("comp2", "opt2")],
                        logfile=(
                            tmp_path / f"COMSOL_{sim_optim.identifier}.log"
                        ).as_posix(),
                    )

                    # Save the results
                    idx_min = test_fit.solution["optimization_objective"][
                        "Objective"
                    ].idxmin()
                    out_fitted_params = test_fit.solution[
                        "optimization_objective"
                    ].drop(columns=["Objective"])

                    # Get the optimized parameters
                    param_list = [col for col in out_fitted_params.columns]

                    for col in out_fitted_params.columns:
                        model.parameter_values[col] = (
                            f"{out_fitted_params[col].iloc[idx_min]}"
                        )

                    # Get average initial SoC, xLi_pos, and xLi_neg
                    act_init_soc = round(np.mean(act_init_soc) * 100, 2)
                    xLi_init_pos = round(np.mean(xLi_init_pos), 6)
                    xLi_init_neg = round(np.mean(xLi_init_neg), 6)

                    out_params[
                        (cell_id, T_expt, s, act_init_soc, xLi_init_pos, xLi_init_neg)
                    ] = sim_optim.get_comsol_parameters(param_list)

                    # Write the optimized parameters to an excel file
                    df = pd.DataFrame.from_dict(out_params, orient="index")

                    # Rename the index columns
                    df.index = pd.MultiIndex.from_tuples(
                        df.index,
                        names=[
                            "Cell-ID",
                            "Temperature [degC]",
                            "SoC [%]",
                            "Avg SoC [%]",
                            "Avg xLi_pos [1]",
                            "Avg xLi_neg [1]",
                        ],
                    )

                    df.to_excel(
                        output_path
                        / f"{today}_optimization_results_{T_expt}degC_{t_opt}s.xlsx"
                    )
                    for key in test_fit.solution.keys():
                        test_fit.solution[key].to_csv(
                            tmp_path / f"out_{sim_optim.identifier}_{key}.csv",
                            index=False,
                        )

                    # Run the validation study

                    logger.info(
                        f"Optimization study for SoC: {s}%, Temperature: {T_expt}degC, Cell: {cell_id} completed, running validation..."
                    )

                    test_val = pycomsol.Study(
                        name="time_transient",
                        tag="time_transient",
                        input_tables=input_tables,
                        output_tables=[
                            "time_probes",
                        ],
                    )
                    sim_val = pycomsol.Simulation(
                        model,
                        identifier=f"{test_type}_T{T_expt}_SoC{s}_Cell_{cell_id}_val",
                        output_path=output_path,
                    )
                    sol_val = sim_val.solve(
                        studies=test_val,
                        drop_physics=[("comp1", "opt"), ("comp2", "opt2")],
                        logfile=(
                            tmp_path / f"COMSOL_{sim_val.identifier}.log"
                        ).as_posix(),
                    )
                    for table_name in sol_val.solution.keys():
                        sol_val.solution[table_name].columns = [
                            col.replace("(", "[")
                            for col in sol_val.solution[table_name].columns
                        ]
                        sol_val.solution[table_name].columns = [
                            col.replace(")", "]")
                            for col in sol_val.solution[table_name].columns
                        ]
                        sol_val.solution[table_name].to_csv(
                            tmp_path / f"out_{sim_val.identifier}.csv",
                            index=False,
                        )

                except Exception as e:
                    logger.error(f"Error occurred: {e}")
                    continue

####################################################################################################
# Step 4: Save the optimization results
####################################################################################################

df = pd.DataFrame.from_dict(out_params, orient="index")
# Rename the index columns
df.index = pd.MultiIndex.from_tuples(
    df.index,
    names=[
        "Cell-ID",
        "Temperature [degC]",
        "SoC [%]",
        "Avg SoC [%]",
        "Avg xLi_pos [1]",
        "Avg xLi_neg [1]",
    ],
)
df.to_excel(output_path / f"{today}_optimization_results_{T_expt}degC_{t_opt}s.xlsx")
