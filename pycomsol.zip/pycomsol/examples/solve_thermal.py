import pycomsol

model_path = "path_to_thermal_model"
parameter_path = "path_to_parameter_file"
model = pycomsol.models.Thermal3D(model_path=model_path, parameters_path=parameter_path)

sim = pycomsol.Simulation(model, study="standard_time")
sol = sim.solve()
