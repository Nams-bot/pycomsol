import pycomsol

pycomsol.comsol_available()
