import pycomsol


# Setp 0: Set the model root path
root_path = r"C:\Users\NamrathaDath\northvolt.com\Simulation and Modeling - Documents\02_Projects\11_VCC_GPA_C\02_Process\07_Cell_Electrochemical\B0.1-RDOE"
# Step 1: Locate the COMSOL model file
model_path = rf"{root_path}\01_Input\Models\LLIB_FullCell_HPPC_MultiObj_CO240511.mph"
output_path = rf"{root_path}\01_Input\Models"

param_filepath = rf"{root_path}\01_Input\GPA-C_B0.1-RDOE_DFN-Parameters.xlsx"
model = pycomsol.DFN(param_filepath, model_path=model_path)

my_first_study = pycomsol.Study(
    name="my_unique_study_name",
    tag="time_transient",
    input_tables={"pulse_data": "path_to_input_csv"},
    output_tables=["time_probes"],
)

sim = pycomsol.Simulation(model, output_path=output_path)
sol = sim.solve(studies=my_first_study)