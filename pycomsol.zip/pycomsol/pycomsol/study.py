from typing import List, Dict


class Study:
    """
    A class to store the information required to run a COMSOL study.

    Parameters
    ----------
    name : str
        A custom name for the study. This name does not need to match
        the name of the COMSOL study. It is only for your own reference.
        If you are passing multiple studies to a Simulation, you should
        ensure this name is different for each study as it will be used
        to identify the study in the output.
    tag : str
        The name of the COMSOL study as written in the model.study_map.
        This doesn't need to be the same as the name of the study in
        COMSOL (which is usually std1, std2, etc.). Instead, it must
        match the key in the model.study_map dictionary (e.g.
        "eis_optimization").
    input_tables : Dict[str, str]
        A dictionary where the keys are the names of input tables
        within the model.input_table_map and the values are the
        filepaths. The filepaths should be relative to the directory
        where you are running the simulation.
    output_tables : List[str]
        A list of the names of the tables you want to output from the
        study. These names must be in the keys in the
        model.output_table_map dictionary.

    Attributes
    ----------
    solution: Dict[str, pd.DataFrame]
        A dictionary where the keys are the names of the output tables
        and the values are the dataframes containing the results of the
        study. This attribute is populated after running the study in a
        simulation.
    """

    def __init__(
        self,
        name: str,
        tag: str,
        input_tables: Dict[str, str] = None,
        output_tables: List[str] = None,
        features: List = None,
        physics: List = None,
    ):
        self.name = name
        self._comsol_name = None
        self.tag = tag
        self.input_tables = input_tables
        self.output_tables = output_tables
        self.features = features
        self.physics = physics
        self.solution = None
        self.dataset = None

    def __repr__(self):
        return f"Study(name={self.name}, comsol_name={self._comsol_name}, dataset={self.dataset})"
