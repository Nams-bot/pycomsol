from math import e
from xml.etree import ElementInclude
import mph
import pandas as pd
from pathlib import Path
import time
import multiprocessing
from rich.progress import Progress, BarColumn, TextColumn
import re
import os


class Simulation:
    """
    A class to run a COMSOL simulation.

    Parameters
    ----------
    model : Model
        The model object containing the information required to run the
        simulation.
    """

    def __init__(self, model, identifier=None, output_path=None):
        self.model = model
        self.identifier = identifier
        self.output_path = output_path

    def solve(self, studies, drop_physics=None, logfile=None, stop_event=None):
        """
        A method to solve the COMSOL model for a list of studies.

        Parameters
        ----------
        studies : List[Study] or Study
            A list of Study objects or a single Study object to solve.
        logfile : str, optional
            The path to a logfile to write the progress of the simulation
            to. If None, no logfile will be written.

        Returns
        -------
        Dict[str, Study]


            the results.

        """

        if not isinstance(studies, list):
            studies = [studies]

        client = mph.start()
        comsol_model = client.load(self.model.model_path)

        if logfile is not None:
            client.java.showProgress(logfile)

        self._set_comsol_parameters(comsol_model)
        self._set_comsol_parameter_tables(comsol_model)

        physics_tags = [p.tag() for p in comsol_model / "physics"]
        if drop_physics != None:
            for component, physics in drop_physics:
                if physics in physics_tags:
                    comsol_model.java.component(component).physics().remove(physics)

        # # Create a simulation stop event
        # stop_event = multiprocessing.Event()

        # # Start progress bar in a separate process
        # CHECK_INTERVAL = 30  # Check every 30 seconds
        # progress_process = multiprocessing.Process(
        #     target=self.progress_bar, args=(stop_event, CHECK_INTERVAL, logfile)
        # )
        # progress_process.start()
        for study in studies:
            study_sol = self._solve_study(comsol_model, study, stop_event=None)

        # # Wait for the progress process to finish
        # progress_process.join()
        if stop_event is not None:
            stop_event.set()
        comsol_model.save(rf"{self.output_path}\model_{self.identifier}.mph")
        client.clear()

        return study_sol

    def evaluate(self, studies, variables, units):
        """
        A method to evaluate the output of a COMSOL study.

        Parameters
        ----------
        studies : List[Study] or Study
            A list of Study objects or a single Study object to evaluate.
        variables : List[str]
            A list of the names of the variables to evaluate.
        units : List[str]
            A list of the units of the variables to evaluate.
        Returns
        -------
        Dict[str, Dict[str, float]]
            A dictionary where the keys are the names of the studies and
            the values are dictionaries where the keys are the names of the
            variables and the values are the evaluated values.

        """

        if not isinstance(studies, list):
            studies = [studies]

        client = mph.start()
        comsol_model = client.load(rf"{self.output_path}\model_{self.identifier}.mph")

        out = {}
        for study in studies:
            out = dict(
                zip(
                    variables,
                    comsol_model.evaluate(variables, units, study.dataset),
                )
            )
        client.clear()

        return out

    def _set_comsol_parameters(self, comsol_model):
        "Apply the parameters values to the comsol model"
        for comsol_name, value in self.model.parameter_values.items():
            comsol_model.parameter(comsol_name, value)

    def get_comsol_parameters(self, parameter_name):
        "Get the parameters values from the comsol model"
        client = mph.start()
        comsol_model = client.load(rf"{self.output_path}\model_{self.identifier}.mph")
        self._set_comsol_parameters(comsol_model)
        out_params = {}
        params_list = [
            p for (p, value) in comsol_model.parameters().items() if p in parameter_name
        ]
        for params in params_list:
            out_params[params] = comsol_model.parameter(params, evaluate=True)
        client.clear()
        return out_params

    def _set_comsol_parameter_tables(self, comsol_model):
        "Apply the parameter table values to the comsol model"

        parameter_tables = self.model.parameter_tables

        cwd = Path(self.output_path)

        for table_name, table in parameter_tables.items():
            comsol_model.java.result().table(table_name).clearTableData()
            temp_path = cwd / "pycomsol_temp_param_table.csv"
            table.to_csv(temp_path.as_posix(), index=False)
            comsol_model.java.result().table(table_name).importData(
                temp_path.as_posix()
            )
            if table_name == "Positive electrode OCP":
                self.model.parameter_values["E_max_pos"] = table[
                    "Positive Electrode OCP [V]"
                ].max()
                self.model.parameter_values["E_min_pos"] = table[
                    "Positive Electrode OCP [V]"
                ].min()
            elif table_name == "Negative electrode OCP":
                self.model.parameter_values["E_max_neg"] = table[
                    "Negative Electrode OCP [V]"
                ].max()
                self.model.parameter_values["E_min_neg"] = table[
                    "Negative Electrode OCP [V]"
                ].min()

        # remove the temp file
        temp_path.unlink()

    def _solve_study(self, comsol_model, study, stop_event):
        "Solve a single study in the comsol model."
        if study.input_tables is not None:
            self._set_input_tables(comsol_model, study)
        self._set_physics(comsol_model, study)
        self._set_features(comsol_model, study)

        study_tag = self.model.study_map[study.tag]

        study._comsol_name = [
            std.name() for std in comsol_model / "studies" if std.tag() == study_tag
        ][0]

        # Save the model before solving
        comsol_model.save(rf"{self.output_path}\model_{self.identifier}.mph")

        # Solve the study
        study_node = [
            std for std in comsol_model / "studies" if std.tag() == study_tag
        ][0]
        comsol_model.solve(study_node)

        # Stop the progress bar
        # stop_event.set()

        # Save the model after solving
        comsol_model.save(rf"{self.output_path}\model_{self.identifier}.mph")

        # Get the output tables
        output_dfs = self._get_output_dfs(comsol_model, study)

        study.solution = output_dfs
        study.dataset = [
            d.name()
            for d in comsol_model / "datasets"
            if study._comsol_name in d.name()
        ][0]

        return study

    def _set_input_tables(self, comsol_model, study):
        "Apply the input tables to the comsol model."
        input_tables = study.input_tables

        input_table_map = self.model.input_table_map

        for table_name, table_path in input_tables.items():
            # Get integer values from the table name
            idx = "".join(filter(str.isdigit, table_name))
            comsol_model.java.result().table(
                input_table_map[table_name]
            ).clearTableData()
            comsol_model.java.result().table(input_table_map[table_name]).importData(
                table_path
            )
            df = pd.read_csv(table_path)
            df.columns = df.columns.str.replace("[(]", "[", regex=True)
            df.columns = df.columns.str.replace("[)]", "]", regex=True)
            # Correct test current due to capacity drift
            SoC_start = comsol_model.evaluate(
                f"Cell_SoC({df['Voltage [V]'].iloc[0]})", "1"
            )[0]
            SoC_end = comsol_model.evaluate(
                f"Cell_SoC({df['Voltage [V]'].iloc[-1]})", "1"
            )[0]
            Q_nominal = comsol_model.parameter("Q_nominal")
            match = re.search(r"[-+]?\d*\.\d+|\d+", Q_nominal)
            if match:
                Q_nominal = float(match.group())
            # Correct test current due to capacity drift only if the test is longer than 1 hour
            if df["Time [s]"].max() > 3600:
                # Step 1: Filter rows where 'value' is nonzero
                nonzero_df = df[df["Current [A]"] != 0].copy()

                # Step 2: Identify continuous blocks of nonzero values
                nonzero_df["group"] = (nonzero_df["Time [s]"].diff() != 1).cumsum()

                # Step 3: Compute duration per group and sum them
                total_time = (
                    nonzero_df.groupby("group")["Time [s]"].max()
                    - nonzero_df.groupby("group")["Time [s]"].min()
                    + 1
                ).sum()

                I_offset = (
                    (
                        (SoC_end - SoC_start) * Q_nominal
                        - df["Capacity [Ah]"][df["Capacity [Ah]"] != 0].iloc[-1]
                    )
                    * 3600
                    / total_time
                ) * 0  # Set to 0 for now
            else:
                I_offset = 0
            comsol_model.parameter("t_max", f"{df['Time [s]'].max()} [s]")
            comsol_model.parameter(f"I_offset{idx}", f"{I_offset} [A]")

    def _set_physics(self, comsol_model, study):
        "Apply the physics values to the comsol model."

        physics = study.physics

        if physics is None:
            return

        for p in physics:
            physics_name = p.name
            for feature in p.features:
                feature_name = feature.name
                for param_name, param_value in feature.attributes.items():
                    comsol_model.java.component("comp1").physics(physics_name).feature(
                        feature_name
                    ).set(param_name, param_value)

    def _set_physics(self, comsol_model, study):
        "Apply the physics values to the comsol model."

        physics = study.physics

        if physics is None:
            return

        for p in physics:
            physics_name = p.name
            for feature in p.features:
                feature_name = feature.name
                for param_name, param_value in feature.attributes.items():
                    comsol_model.java.component("comp1").physics(physics_name).feature(
                        feature_name
                    ).set(param_name, param_value)

    def _set_features(self, comsol_model, study):
        "Apply the feature values to the comsol model."

        features = study.features
        study_tag = self.model.study_map[study.tag]

        if features is None:
            return

        for feature in features:
            feature_name = feature.name

            for param_name, param_value in feature.attributes.items():
                comsol_model.java.study(study_tag).feature(feature_name).set(
                    param_name, param_value
                )

    def _get_output_dfs(self, comsol_model, study):
        "Obtain the output tables from the comsol model."
        output_tables = study.output_tables
        output_table_map = self.model.output_table_map

        output_dfs = {}
        if output_tables == ["All"]:
            output_tables = list(output_table_map.keys())
            for table_name in output_tables:
                table_tag = output_table_map[table_name]
                output_dfs[table_name] = self._get_df_from_comsol(
                    comsol_model, table_tag
                )
        else:
            for table_name in output_tables:
                table_tag = output_table_map[table_name]
                output_dfs[table_name] = self._get_df_from_comsol(
                    comsol_model, table_tag
                )

        return output_dfs

    def _get_df_from_comsol(self, comsol_model, table_tag):
        "Convert a comsol table to a pandas dataframe."
        table = list(comsol_model.java.result().table(table_tag).getTableData(False))
        header = [
            str(x)
            for x in list(
                comsol_model.java.result().table(table_tag).getColumnHeaders()
            )
        ]
        df = pd.DataFrame(
            [[float(str(y)) for y in list(x)] for x in table], columns=header
        )
        return df

    def progress_bar(self, stop_event, check_interval, LOG_FILE):
        """Monitors the log file and updates the progress bar at the given interval."""
        if not os.path.exists(LOG_FILE):
            raise FileNotFoundError(f"Log file not found: {LOG_FILE}")
        with Progress(
            TextColumn("[cyan]{task.description}"),
            BarColumn(),
            TextColumn("[green]{task.percentage:>3.0f}%"),
        ) as progress:
            task = progress.add_task("Processing...", total=100)

            while not stop_event.is_set():
                current_progress = self.extract_progress_from_log(LOG_FILE)
                progress.update(task, completed=min(current_progress, 100))

                if current_progress >= 100:  # Stop when we reach 100%
                    break

                time.sleep(check_interval)  # Wait for the next check

            # Ensure progress bar completes fully
            progress.update(task, completed=100)

    def extract_progress_from_log(LOG_FILE="comsol_progress.log"):
        """Reads the latest progress percentage from the log file."""
        if not os.path.exists(LOG_FILE):
            return 0  # Default to 0% if file doesn't exist

        with open(LOG_FILE, "r") as f:
            lines = f.readlines()

        # Find the last occurrence of the progress percentage
        for line in reversed(lines):
            match = re.search(r"Current Progress:\s*(\d+)\s*%", line)
            if match:
                return int(match.group(1))  # Extract progress value
        return 0  # Default if no progress found
