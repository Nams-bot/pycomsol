class BasePhysics:

    def __init__(self, name: str, features: list = []):
        self.name = name
        self.features = features
