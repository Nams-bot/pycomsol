from ..features.global_objective_features import GlobalObjectiveFeatures
from .base_physics import BasePhysics


class GlobalOptimization(BasePhysics):
    """
    Class to provide a simple interface for adding and accessing
    the objective function for an optimization study.

    Attributes
    ----------
    features : list
        List of dictionaries containing the features for the optimization study.

    """

    def add_objective(
        self,
        name: str,
        input_table: str,
        time_col: int,
        use_cols: list,
        col_units: list,
        model_vars: list,
    ):
        """
        Add an objective to the optimization study.
        """
        feature = GlobalObjectiveFeatures(name)
        feature.add_attributes(
            table_tag=input_table,
            time_col=time_col,
            use_cols=use_cols,
            col_units=col_units,
            model_vars=model_vars,
        )
        self.features.append(feature)
