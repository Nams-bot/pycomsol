from .base_features import BaseFeatures


class OptimizationFeatures(BaseFeatures):
    """
    Class to provide a simple interface for adding and accessing
    the features for an optimization study.

    Attributes
    ----------
    features : list
        List of dictionaries containing the features for the optimization study.

    """

    def __init__(self, name: str):
        """
        Initialize the OptimizationFeatures class.

        Parameters
        ----------
        name : str
            Name of the optimization study.

        """
        super().__init__(name)
        self.attributes = {
            "pname": [],
            "initval": [],
            "scale": [],
            "lbound": [],
            "ubound": [],
        }

    def add_parameter(self, name, initial_value, scale, lower_bound, upper_bound):
        """
        Add a parameter to the optimization study.
        """
        self.attributes["pname"].append(name)
        self.attributes["initval"].append(str(initial_value))
        self.attributes["scale"].append(str(scale))
        self.attributes["lbound"].append(str(lower_bound))
        self.attributes["ubound"].append(str(upper_bound))
