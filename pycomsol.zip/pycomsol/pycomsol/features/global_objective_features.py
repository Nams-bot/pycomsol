from .base_features import BaseFeatures


class GlobalObjectiveFeatures(BaseFeatures):
    """
    Class to provide a simple interface for adding and accessing
    the features for an optimization global objective.

    Attributes
    ----------
    attributes : Dict
        Dictionaries containing the features for the optimization study.

    """

    def __init__(self, name: str):
        """
        Initialize the OptimizationFeatures class.

        Parameters
        ----------
        name : str
            Name of the optimization study.

        """
        super().__init__(name)
        self.attributes = {
            "dataSource": "table",
            "table": "",
            "parameterColumn": "1",
            "use": [],
            "dataUnit": [],
            "modelExpression": [],
        }

    def add_attributes(
        self,
        table_tag: str,
        time_col: int,
        use_cols: list,
        col_units: list,
        model_vars: list,
    ):
        """
        Add an objective function to the optimization study.
        """
        self.attributes["table"] = table_tag
        self.attributes["parameterColumn"] = time_col
        self.attributes["use"] = use_cols
        self.attributes["dataUnit"] = col_units
        self.attributes["modelExpression"] = model_vars
