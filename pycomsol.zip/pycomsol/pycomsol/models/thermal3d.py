from .base_model import BaseModel


class Thermal(BaseModel):

    def __init__(self, model_path: Path):
        # run the parent class init
        self.model_path = model_path
        self.studies = ThermalStudies()
        self.probe_table_name = None

        super().__init__()
