import re
import pandas as pd


class BaseModel:
    """
    A base class to store the information required to run a COMSOL model. Only
    the default values are set in the subclasss (e.g. DFN) and the user can
    override these values by passing them as arguments.

    Parameters
    ----------
    parameter_filepath : str
        The path to the excel file containing the parameters for the model.
    parameter_sheet_name : str, optional
        The name of the sheet in the excel file containing the parameters.
    parameter_map : dict, optional
        A dictionary where the keys are the names of the parameters in the
        excel file and the values are the names of the parameters in the
        COMSOL model.
    parameter_table_map : dict, optional
        A dictionary where the keys are the names of the tables in the excel
        file and the values are the names of the tables in the COMSOL model.
    model_path : str, optional
        The path to the COMSOL model file.
    study_map : dict, optional
        A dictionary where the keys are the names of the studies in the COMSOL
        model and the values are the names of the studies in the excel file.
    input_table_map : dict, optional
        A dictionary where the keys are the names of the input tables in the
        COMSOL model and the values are the names of the tables in the excel
        file.
    output_table_map : dict, optional
        A dictionary where the keys are the names of the output tables in the
        COMSOL model and the values are the names of the tables in the excel
        file.
    is_coin : bool, optional
        A flag to indicate if the model is for a coin cell. If True, the
        negative electrode parameters are not read from the excel file and
        the electrode area parameters are overwritten.

    Attributes
    ----------
    parameter_values : dict
        A dictionary where the keys are the names of the parameters in the
        COMSOL model and the values are the values of the parameters.
    parameter_tables : dict
        A dictionary where the keys are the names of the tables in the COMSOL
        model and the values are the tables as pandas DataFrames.

    """

    def __init__(
        self,
        parameter_filepath,
        parameter_sheet_name=None,
        parameter_map=None,
        parameter_table_map=None,
        model_path=None,
        study_map=None,
        input_table_map=None,
        output_table_map=None,
        is_coin=False,
    ):

        self.parameter_filepath = parameter_filepath
        self._set_defaults()

        self._set_parameter_sheet_name(parameter_sheet_name)
        self._set_parameter_map(parameter_map)
        self._set_parameter_table_map(parameter_table_map)
        self._set_model_path(model_path)
        self._set_study_map(study_map)
        self._set_input_table_map(input_table_map)
        self._set_output_table_map(output_table_map)

        self._set_parameters(parameter_filepath, is_coin)

    def _set_defaults(self):
        self._default_model_path = None
        self._default_parameter_sheet_name = None
        self._default_study_map = {}
        self._default_parameter_map = {}
        self._default_parameter_table_map = {}
        self._default_input_table_map = {}
        self._default_output_table_map = {}

    def _set_model_path(self, model_path):
        self.model_path = self._default_model_path
        if model_path is not None:
            self.model_path = model_path

    def _set_parameter_sheet_name(self, parameter_sheet_name):
        self.parameter_sheet_name = self._default_parameter_sheet_name
        if parameter_sheet_name is not None:
            self.parameter_sheet_name = parameter_sheet_name

    def _set_parameter_map(self, parameter_map):
        self.parameter_map = self._default_parameter_map

        if parameter_map is not None:
            self.parameter_map.update(parameter_map)

    def _set_parameter_table_map(self, parameter_table_map):
        self.parameter_table_map = self._default_parameter_table_map

        if parameter_table_map is not None:
            self.parameter_table_map.update(parameter_table_map)

    def _set_input_table_map(self, input_table_map):
        self.input_table_map = self._default_input_table_map

        if input_table_map is not None:
            self.input_table_map.update(input_table_map)

    def _set_output_table_map(self, output_table_map):
        self.output_table_map = self._default_output_table_map

        if output_table_map is not None:
            self.output_table_map.update(output_table_map)

    def _set_study_map(self, study_map=None):
        self.study_map = self._default_study_map

        if study_map is not None:
            self.studies.update(study_map)

    def _set_tables(self, additional_tables=None):

        self.tables = self._default_tables

        if additional_tables is not None:
            self.tables.update(additional_tables)

    def _set_parameters(self, param_file, is_coin=False):

        # Read parameters from an excel sheet
        excel_df = pd.read_excel(
            param_file,
            sheet_name=self.parameter_sheet_name,
            index_col=0,
            usecols="A,B",
            nrows=38,
            header=0,
        )

        # Remove any rows with NaN values
        excel_df = excel_df.dropna()

        # Assign the parameters to the model
        parameter_values = {}
        for excel_name, row in excel_df.iterrows():

            # Don't need negative electrode parameters for coin cell
            if is_coin and "Negative" in excel_name:
                continue

            # Fetch the unit from the excel_name (if available)
            if "[" in excel_name and "]" in excel_name:
                unit = re.search(r"(\[.*?\])", excel_name).group(1)
            else:
                unit = ""

            if excel_name in self.parameter_map:
                comsol_name = self.parameter_map[excel_name]
                comsol_value = f"{row.values[0]}{unit}"

                parameter_values[comsol_name] = comsol_value

        # for coin cells, overwrite the electrode area parameters
        if is_coin:
            parameter_values["A_electrode"] = "0.00017671[m^2]"
            parameter_values["N_electrode_pairs"] = "1"

        self.parameter_values = parameter_values

        # Set properties from the tables
        parameter_tables = {}
        for excel_name, comsol_name in self.parameter_table_map.items():
            df = pd.read_excel(param_file, sheet_name=excel_name)
            parameter_tables[comsol_name] = df

        self.parameter_tables = parameter_tables
