from .base_model import BaseModel


class DFN(BaseModel):
    """
    A class that contains the default configuration for interfacing
    with the COMSOL DFN model. This configuration can be modified by
    passing arguments to the class. The following are available:

    Studies:
        - time_transient: Transient simulation in the time domain.
        - frequency_transient: Transient simulation in the frequency domain.
        - parametric_time: Parametric sweep in the time domain.
        - parametric_frequency: Parametric sweep in the frequency domain.

    Input tables:
        - pocv_data: Data for the POCV curves.
        - eis_data: Data for the EIS measurements.
        - pulse_data: Data for the pulse experiments.

    Output tables:
        - time_probes: Data for the time domain transient simulation.
        - eis_probe: Data for the EIS simulation.
        - eis_optimization_objective: Data for the EIS optimization.
    """

    def _set_defaults(self):

        self._default_parameter_sheet_name = "Parameters"
        self._default_model_path = None

        self._default_parameter_map = {
            "Number of electrode pairs connected in parallel to make a cell": "N_electrode_pairs",
            "Lower voltage cut-off [V]": "Ecell_min",
            "Upper voltage cut-off [V]": "Ecell_max",
            "Nominal cell capacity [A*h]": "Q_nominal",
            "Ambient temperature [K]": "T_ambient",
            "Reference temperature [K]": "T_ref",
            "Electrode area [m^2]": "A_electrode",
            "Fraction of area lost": "F_area_loss",
            "Component resistance [Ohm]": "R_cc",
            "Electrolyte initial concentration [mol/m^3]": "c_init_electrolyte",
            "Separator thickness [m]": "d_separator",
            "Separator porosity": "eps_pore_separator",
            "Separator MacMullin number": "nm_separator",
            "Positive electrode thickness [m]": "d_coat_pos",
            "Positive electrode porosity": "eps_pore_pos",
            "Positive electrode active material volume fraction": "eps_active_pos",
            "Positive electrode maximum concentration [mol/m^3]": "c_max_pos",
            "Positive electrode particle radius [m]": "r_particle_pos",
            "Positive electrode MacMullin number": "nm_pos",
            "Positive electrode conductivity [S/m]": "sigma_pos",
            "Positive electrode symmetry factor": "a_pos",
            "Positive electrode SoC100 stoichiometry": "xLi_100_pos",
            "Positive electrode SoC0 stoichiometry": "xLi_0_pos",
            "Positive electrode foil thickness [m]": "d_foil_pos",
            "Negative electrode thickness [m]": "d_coat_neg",
            "Negative electrode porosity": "eps_pore_neg",
            "Negative electrode active material volume fraction": "eps_active_neg",
            "Negative electrode maximum concentration [mol/m^3]": "c_max_neg",
            "Negative electrode particle radius [m]": "r_particle_neg",
            "Negative electrode MacMullin number": "nm_neg",
            "Negative electrode conductivity [S/m]": "sigma_neg",
            "Negative electrode symmetry factor": "a_neg",
            "Negative electrode SoC100 stoichiometry": "xLi_100_neg",
            "Negative electrode SoC0 stoichiometry": "xLi_0_neg",
            "Negative electrode foil thickness [m]": "d_foil_neg",
            "Negative electrode SEI conductivity [S/m]": "sigma_sei_neg",
            "Negative electrode SEI thickness [m]": "d_sei_neg",
        }

        self._default_parameter_table_map = {
            "Positive electrode OCP": "tbl1",
            "Positive electrode dOCPdT": "tbl2",
            "Positive electrode diffusivity": "tbl3",
            "Positive electrode kinetic rate": "tbl4",
            "Positive electrode capacitance": "tbl5",
            "Electrolyte properties": "tbl6",
            "Negative electrode OCP": "tbl7",
            "Negative electrode dOCPdT": "tbl8",
            "Negative electrode diffusivity": "tbl9",
            "Negative electrode kinetic rate": "tbl10",
            "Negative electrode capacitance": "tbl11",
            "Cell OCP": "tbl12",
        }

        self._default_material_map = {
            "Positive Foil": "mat1",
            "Positive electrode": "mat2",
            "Electrolyte": "mat3",
            "Negative electrode": "mat4",
            "Negative Foil": "mat5",
        }

        self._default_study_map = {
            "time_transient": "std1",
            "frequency_transient": "std2",
            "parametric_time": "std3",
            "parametric_frequency": "std4",
            "time_optimize": "std5",
            "frequency_optimize": "std6",
            "time_parameter_estimation": "std7",
            "initialize_soc": "std8",
        }

        self._default_input_table_map = {
            "test_data1": "tbl13",
            "test_data2": "tbl14",
            "test_data3": "tbl22",
            "test_data4": "tbl23",
        }

        self._default_output_table_map = {
            "time_probes": "tbl15",  # TODO: add proper tag
            "eis_probe": "tbl16",
            "eis_optimization_objective": "tbl17",
            "optimization_objective": "tbl18",
            "optimization_error": "tbl19",
            "parameter_confidence": "tbl20",
            "parameter_covariance": "tbl21",
        }
