from .base_material import BaseMaterial


class BatteryElectrodeMaterial(BaseMaterial):
    """
    A class that contains the default configuration for interfacing
    with the COMSOL battery electrode material. This configuration can be
    modified by passing arguments to the class. The following are available:

    Parameters:
        - name: Name of the material.
        - model: Model object to which the material belongs.
        - properties: Dictionary of material properties.
    """

    def __init__(self, model, name, properties=None):
        super().__init__(model, name)
        if properties is not None:
            self.properties = properties

    def __repr__(self):
        return f"<{self.__class__.__name__} '{self.name}'>"

    def __str__(self):
        return self.name
