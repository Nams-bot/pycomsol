class BaseMaterial:
    def __init__(self, model, name):
        self.model = model
        self.name = name

    def __repr__(self):
        return f"<{self.__class__.__name__} '{self.name}'>"

    def __str__(self):
        return self.name

    @property
    def properties(self):
        return self.model.get_material_properties(self.name)

    @properties.setter
    def properties(self, properties):
        self.model.set_material_properties(self.name, properties)

    def delete(self):
        self.model.delete_material(self.name)
