import mph
import pandas as pd
from rdp import rdp
import time
import re
import os
from rich.progress import Progress, BarColumn, TextColumn


def comsol_available():
    """
    Check if COMSOL is available on the system.

    Returns
    -------
    bool
        True if COMSOL is available, False otherwise.
    """

    # check if COMSOL is available
    try:
        client = mph.start()
        client.close()
    except Exception:
        return False

    return True


def df_to_table(model, data, table_tag):
    """Write data to a table"""
    data.to_csv("data.csv", index=False)
    model.java.result().table(table_tag).importData("data.csv")
    return


def table_to_df(model, table_tag):
    table = list(model.java.result().table(table_tag).getTableData(False))
    header = [
        str(x) for x in list(model.java.result().table(table_tag).getColumnHeaders())
    ]
    df = pd.DataFrame([[float(str(y)) for y in list(x)] for x in table], columns=header)
    return df


def data_subsample(data, col_t=None, col_v=None, epsilon=0.0005):
    """
    Subsample using the Ramer-Douglas-Peucker algorithm.

    Args:
        data (pd.DataFrame): Time series with 'time' and 'value' columns.
        epsilon (float): Maximum allowed perpendicular distance.

    Returns:
        pd.DataFrame: Subsampled time series.
    """
    points = data[[col_t, col_v]].values
    subsampled_points = rdp(points, epsilon=epsilon)
    subsampled_data = pd.DataFrame(subsampled_points, columns=[col_t, col_v])
    out_data = data[data[col_t].isin(subsampled_data[col_t])]
    return out_data


def extract_progress_from_log(log_file):
    """Reads the latest progress percentage from the log file."""
    if not os.path.exists(log_file):
        return 0  # Default to 0% if file doesn't exist

    with open(log_file, "r") as f:
        lines = f.readlines()

    # Find the last occurrence of the progress percentage
    for line in reversed(lines):
        match = re.search(r"Current Progress:\s*(\d+)\s*%", line)
        if match:
            return int(match.group(1))  # Extract progress value
    return 0  # Default if no progress found


def progress_bar(stop_event, log_file, check_interval):
    """Monitors the log file and updates the progress bar at the given interval."""
    with Progress(
        TextColumn("[cyan]{task.description}"),
        BarColumn(),
        TextColumn("[green]{task.percentage:>3.0f}%"),
    ) as progress:
        task = progress.add_task("Processing...", total=100)

        while not stop_event.is_set():
            current_progress = extract_progress_from_log(log_file)
            progress.update(task, completed=min(current_progress, 100))

            if current_progress >= 100:  # Stop when we reach 100%
                break

            time.sleep(check_interval)  # Wait for the next check

        # Ensure progress bar completes fully
        progress.update(task, completed=100)
