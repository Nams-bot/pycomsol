#
# Tests for the Simulation class
#
import unittest
import pycomsol
from pathlib import Path

cfp = Path(__file__).resolve()
data_folder = cfp.parent.parent / "data_for_testing"
param_path = data_folder / "parameters_for_testing.xlsx"

model = pycomsol.BaseModel(
    parameter_filepath=param_path,
    parameter_sheet_name="ParametersExample",
    parameter_map={"a": "comsol_a", "b": "comsol_b", "c": "comsol_c"},
    model_path="example_model_path.mph",
    parameter_table_map={
        "TableExample1": "comsol_table1",
        "TableExample2": "comsol_table2",
    },
    input_table_map={
        "input_table1": "comsol_input_table1",
        "input_table2": "comsol_input_table2",
    },
    output_table_map={
        "output_table1": "comsol_output_table1",
        "output_table2": "comsol_output_table2",
    },
)


class TestSimulation(unittest.TestCase):

    def test_init(self):
        sim = pycomsol.Simulation(model)
        self.assertEqual(sim.model, model)


# @unittest.skipIf(not pycomsol.comsol_available(), "comsol not available")
