#
# Tests for the Study class
#
import unittest
import pycomsol


class TestStudy(unittest.TestCase):

    def test_init(self):

        study = pycomsol.Study(
            name="study",
            tag="tag",
            input_tables={"table1": "path/to/table1.csv"},
            output_tables=["table2"],
            features=[{"feature1": 1, "feature2": 2}],
        )

        self.assertEqual(study.name, "study")
        self.assertEqual(study.tag, "tag")
        self.assertEqual(study.input_tables, {"table1": "path/to/table1.csv"})
        self.assertEqual(study.output_tables, ["table2"])
        self.assertEqual(study.features, [{"feature1": 1, "feature2": 2}])
        self.assertIsNone(study.solution)

    def test_adding_solution(self):
        study = pycomsol.Study(
            name="study",
            tag="tag",
            input_tables={"table1": "path/to/table1.csv"},
            output_tables=["table2"],
            features=[{"feature1": 1, "feature2": 2}],
        )

        study.solution = {"table2": "solution"}
        self.assertEqual(study.solution, {"table2": "solution"})
