#
# Tests for the BaseModel class
#
import unittest
import pycomsol
import pandas as pd
from pathlib import Path


# get the current file path
cfp = Path(__file__).resolve()
data_folder = cfp.parent.parent.parent / "data_for_testing"
param_path = data_folder / "parameters_for_testing.xlsx"


class TestBaseModel(unittest.TestCase):

    def test_init(self):

        model = pycomsol.BaseModel(
            parameter_filepath=param_path,
            parameter_sheet_name="ParametersExample",
            parameter_map={"a": "comsol_a", "b": "comsol_b", "c": "comsol_c"},
            model_path="example_model_path.mph",
            parameter_table_map={
                "TableExample1": "comsol_table1",
                "TableExample2": "comsol_table2",
            },
            input_table_map={
                "input_table1": "comsol_input_table1",
                "input_table2": "comsol_input_table2",
            },
            output_table_map={
                "output_table1": "comsol_output_table1",
                "output_table2": "comsol_output_table2",
            },
        )

        # check that the parameters are set correctly
        self.assertEqual(model.parameter_filepath, param_path)
        self.assertEqual(model.parameter_sheet_name, "ParametersExample")
        self.assertEqual(
            model.parameter_map, {"a": "comsol_a", "b": "comsol_b", "c": "comsol_c"}
        )
        self.assertEqual(model.model_path, "example_model_path.mph")

        self.assertEqual(
            model.parameter_table_map,
            {"TableExample1": "comsol_table1", "TableExample2": "comsol_table2"},
        )

        self.assertEqual(
            model.input_table_map,
            {
                "input_table1": "comsol_input_table1",
                "input_table2": "comsol_input_table2",
            },
        )

        self.assertEqual(
            model.output_table_map,
            {
                "output_table1": "comsol_output_table1",
                "output_table2": "comsol_output_table2",
            },
        )

        # test that the parameters have been loaded in correctly
        parameter_values = model.parameter_values

        self.assertEqual(parameter_values["comsol_a"], str(10.0))
        self.assertEqual(parameter_values["comsol_b"], str(5.0))
        self.assertEqual(parameter_values["comsol_c"], str(3.2))

        # check that the parameter_tables have been loaded in correctly
        parameter_tables = model.parameter_tables

        df_1 = parameter_tables["comsol_table1"]
        df_2 = parameter_tables["comsol_table2"]

        self.assertEqual(df_1.shape, (5, 2))
        self.assertEqual(df_2.shape, (6, 2))

        df_1_expected = pd.DataFrame(
            {
                "xx": [0, 0.2, 0.5, 0.8, 1],
                "f(xx)": [105.8, 95.6, 39, 52, -9],
            }
        )

        self.assertTrue(df_1.equals(df_1_expected))

        df_2_expected = pd.DataFrame(
            {
                "zz": [-5, 0, 5, 10, 50, 100],
                "f(zz)": [92, 500, 900, 1500, 1900, 4000],
            }
        )
        self.assertTrue(df_2.equals(df_2_expected))
