#
# Tests for the OptimizationFeatures class
#
import unittest
import pycomsol


class TestOptimizationFeatures(unittest.TestCase):

    def test_add_parameter(self):
        opt = pycomsol.OptimizationFeatures()
        opt.add_parameter("f_Rc", -2, 1, -9, 2)

        feature = opt.features[0]
        self.assertEqual(feature["pname"], "f_Rc")
        self.assertEqual(feature["initval"], "-2")
        self.assertEqual(feature["scale"], "1")
        self.assertEqual(feature["lbound"], "-9")
        self.assertEqual(feature["ubound"], "2")
